var by__index_8h =
[
    [ "fill_squares_by_index", "by__index_8h.htm#aaae0909cd45215400b334e2e9077944e", null ],
    [ "fill_values_by_index", "by__index_8h.htm#aec35349b7b72be562e914bd4a6b48d17", null ],
    [ "print_by_index", "by__index_8h.htm#a37d8169ce7d7e015c5c08fe73c58368a", null ]
];