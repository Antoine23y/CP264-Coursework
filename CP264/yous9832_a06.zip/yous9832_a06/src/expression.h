/*
--------------------------------------------------
Project: a6q3
File:    expression.h
Author:  Antoine Youssef, 169069832, yous9832@mylaurier.ca
Version: 2025-01-16
--------------------------------------------------
*/

#ifndef EXPRESSION_H
#define EXPRESSION_H

#include "common.h"
#include "queue.h"

QUEUE infix_to_postfix(char *infixstr);

int evaluate_postfix(QUEUE queue);

int evaluate_infix(char *infixstr);

#endif
