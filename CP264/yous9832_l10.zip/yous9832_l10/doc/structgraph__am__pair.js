var structgraph__am__pair =
[
    [ "col", "structgraph__am__pair.htm#afe02d10a525bd02a22cea864b69bc4b0", null ],
    [ "row", "structgraph__am__pair.htm#aeb975368259c168c0f9c3dfe9f043949", null ]
];