var data_8h =
[
    [ "BOOL_STR", "data_8h.htm#ae6884e951887c44b96cde996ae49b3d9", null ],
    [ "DATA_STRING_SIZE", "data_8h.htm#ab88fd267c06208494c2d2dd492547f43", null ],
    [ "data_ptr", "data_8h.htm#a8f1c9fafcef5a26e0b113b99d63365b1", null ],
    [ "data_compare", "data_8h.htm#a83e6d88f2abf7134939634275b438f24", null ],
    [ "data_copy", "data_8h.htm#ad574f4c71681dcf17fd9be852a76b685", null ],
    [ "data_free", "data_8h.htm#a3faff1037e15e8cb04dd463434b1ae6e", null ],
    [ "data_string", "data_8h.htm#a3880a7abef51db7b3b4929a6a466c52e", null ]
];