var structavl__linked =
[
    [ "count", "structavl__linked.htm#ae1644add126c0811491a5aab322d5066", null ],
    [ "root", "structavl__linked.htm#a1e11fa45903e4d62c29a66bec14508ac", null ]
];