var data_8c =
[
    [ "data_compare", "data_8c.htm#a51c3c224947e26a6356409603f04629a", null ],
    [ "data_copy", "data_8c.htm#ad574f4c71681dcf17fd9be852a76b685", null ],
    [ "data_free", "data_8c.htm#a3faff1037e15e8cb04dd463434b1ae6e", null ],
    [ "data_string", "data_8c.htm#a65dd90c7cd3b02715432e7b26dbd5c3b", null ]
];